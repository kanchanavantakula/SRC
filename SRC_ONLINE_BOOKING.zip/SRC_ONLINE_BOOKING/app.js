const express = require("express");
const ejs = require("ejs");
const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");
const multer = require("multer");
const session = require("express-session");
const passport = require("passport");
const passportLocalMongoose = require("passport-local-mongoose");
const findOrCreate = require("mongoose-findorcreate");
const alert = require("alert");
const { table } = require("console");

const app = express();

app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(express.static("public"));
app.use(express.static(__dirname + "uploads"));

app.use(
    session({
      secret: "Our little secret.",
      resave: false,
      saveUninitialized: false,
    })
);

app.use(passport.initialize());
app.use(passport.session());


app.get("/", function(req, res){
    // console.log(__dirname)
    
    res.render("index");
})


app.get("/login", function(req, res){
    res.render("login");
});
app.get("/register", function(req, res){
    res.render("register");
});

app.get("/allMovies", function (req, res) {
    if (req.isAuthenticated()) {
  
      let movies = [];
      Movie.find({}, function(err, allMovies){
        if(err){
          console.log(err);
        }else{
            movies = allMovies;
          res.render("allMovies", {movies: movies});
        }
    
      });
  
    } else {
      res.render("login");
    }
  });


  app.get("/movie/:movieId", function (req, res) {
    
    if(req.isAuthenticated()){
      let requestedMovieId = req.params.movieId;
      console.log(requestedMovieId);
  
      Movie.findOne({_id:requestedMovieId}, function(err, movie){
          if(err){
            console.log("Something is wrong...");
            console.log(err)
          }else{
              console.log("Selected product is : ");
              console.log(movie);
            res.render("movie", {movie});
      
          }
        });
  
    }else{
        res.render("login");
    }
  });

app.get("/profile", function (req, res) {
    console.log(req.user);
  if(req.isAuthenticated()){
    let currentUser = `${req.user._id}`.split('"')[0];
    console.log(currentUser);

    User.findOne({_id:currentUser}, function(err, user){
        if(err){
          console.log("Something is wrong...");
          console.log(err)
        }else{
            console.log("Current user is : ");
            console.log(user);
          res.render("profile", {user});
    
        }
      });

    // res.render("myProfile");

  }else{
      res.render("login");
  }
});

app.get("/myMovies", function (req, res) {


    if (req.isAuthenticated()) {
  
    //   console.log(req)
    
      let user = req.user._id;
    
      let orders = [];
      Order.find({}, function(err, allOrders){
        if(err){
          console.log(err);
        }else{
          orders = allOrders;
          res.render("myMovies", {orders: orders, currentUser: user, orders});
        }
      });
  
  
    }
  
  });

// establishing connection with database
//mongoose

mongoose
  .connect("mongodb://127.0.0.1:27017/SRC", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connection successfull....");
  })
  .catch((err) => {
    console.log(err);
  });

  const userSchema = new mongoose.Schema({
    username: String,
    fullName: String,
    phoneNumber: String,
    email: String,
    collegeId: String,
    idImage: String,
    profileImage: String,
    type: String
  });

  userSchema.plugin(passportLocalMongoose);
userSchema.plugin(findOrCreate);

const User = new mongoose.model("User", userSchema);
passport.use(User.createStrategy());

passport.serializeUser(function (user, done) {
    done(null, user.id);
  });
  passport.deserializeUser(function (id, done) {
    User.findById(id, function (err, user) {
      done(err, user);
    });
  });


//register user
let randomNumber = Math.floor(Math.random() * 1000000 + 1);
let newName;
let extensions = [];
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/uploads");
  },
  filename: function (req, file, cb) {
    newName = file.fieldname + randomNumber + path.extname(file.originalname);
    extensions.push(path.extname(file.originalname));
    cb(null, newName);
  },
});

var upload = multer({ storage: storage });

var uploadMultiple = upload.fields([
  { name: "IdCardImage", maxCount: 10 },
  { name: "ProfileImage", maxCount: 10 },
]);

app.post(
  "/register",
  uploadMultiple,
  function (req, res, next) {
    console.log(req.body);
    const user = new User({
      username: req.body.username,
      fullName: req.body.fullName,
      phoneNumber: req.body.phoneNumber,
      email: req.body.username,
      collegeId: req.body.collegeId,
      idImage: `IdCardImage${randomNumber}${extensions[0]}`,
      profileImage: `ProfileImage${randomNumber}${extensions[1]}`,
      type: "Normal"
    });
    User.register(user, req.body.password, function (err, user) {
      if (err) {
        console.log(err);
        console.log("error")
        return res.redirect("/register");
      }
      next();
    });
    extensions = [];
    randomNumber = Math.floor(Math.random() * 1000000 + 1);
  },
  passport.authenticate("local", {
    successRedirect: "/allMovies",
    failureRedirect: "/register",
  })
);


//login user
app.post("/login", function (req, res) {
    console.log(req.body);
    const user = new User({
        username: req.body.username,
        password: req.body.password
    });
  
    req.login(user, function(err){
        if(err){
            console.log("Login Failed....");
            console.log(err);
            return res.redirect("/login");
        }else{
            passport.authenticate("local")(req, res, function(){
                console.log("Login Success...");
                res.redirect("/allMovies");
            });
        }
    })
  });

app.get('/logout', function(req, res, next) {
    randomNumber = Math.floor(Math.random() * 1000000 + 1);
    console.log("Logged out....");
    req.logout(function(err) {
      if (err) { return next(err); }
      res.redirect('/');
    });
  });


app.listen(3333, function(){
    console.log("Server started at http://localhost:3333");
})


app.get("/addMovie", function(req, res){
    if(req.isAuthenticated()){
        // console.log("User - ", req.user);
        if(req.user.type=="Admin"){
            res.render("addMovie");
        }else{
            res.redirect("/")
        }
    }else{
        res.redirect("/")
    }
})


// adding a new movie
const movieSchema = new mongoose.Schema({
    movieName: String,
    onlyFor: String,
    ticketPrice: String,
    showDate: String,
    showTime: String,
    movieDescription: String,
    movieThumbnail: String,
    status: String,
    tickets: Number,
  });
const Movie = new mongoose.model("Movie", movieSchema);

var uploadThumbnail = upload.fields([
    { name: "movieThumbnail", maxCount: 10 }
  ]);

app.post("/addMovie", uploadThumbnail, function(req, res){

    const newMovie = new Movie({
        movieName: req.body.movieName,
        onlyFor: req.body.onlyFor,
        ticketPrice: req.body.ticketPrice,
        showDate: req.body.showDate,
        showTime: req.body.showTime,
        movieDescription: req.body.movieDescription,
        movieThumbnail: `movieThumbnail${randomNumber}${extensions[0]}`,
        status: "Pending",
        tickets: 350,
    });

    newMovie.save(function(err){
        if(!err){
          randomNumber = Math.floor(Math.random() * 1000000 + 1);
          extensions = [];
          alert("Movie addedd successfully...");
          res.redirect("/allMovies");
        }else{
          alert("Failed to add movie to DB...");
          console.log(err);
        }
      });
    
})

const orderSchema = new mongoose.Schema({
    UserName: String,
    phoneNumber: String,
    email: String,
    collegeId: String,
    movieName: String,
    showDate: String,
    showTime: String,
    movieId: String,
    userId: String,
    status: String,
    ticketsBooked: String,
    movieThumbnail: String
  });

  const Order = new mongoose.model("Order", orderSchema);

app.post("/book", function(req, res){
    // alert('woking')
    console.log(req.body);
    let currentMovie = req.body.currentMovie;
    let requestedTickets = req.body.tickets;
    let currentAvailableTickets = req.body.currentAvailableTickets;
    let newTickets = (+currentAvailableTickets) - (+requestedTickets);

    // console.log("current movie: ", currentMovie);
    // console.log("requested tickets: ", requestedTickets);
    // console.log("current available tickets: ", currentAvailableTickets);
    // console.log("new tickets: ", newTickets);

    if(+currentAvailableTickets<+requestedTickets){
        alert("Invalid ticket count...");
        res.redirect("allMovies");

    }else{
        Movie.updateOne({_id: currentMovie}, {$set:{tickets: newTickets}}, function(err){
            if(!err){
              console.log('Tickets updated...');
            }else{
              console.log('Failed to update tickets');
      
            }
          });

        // place new item in orders table
        const newOrder = new Order({
            UserName: req.user.fullName,
            phoneNumber: req.user.phoneNumber,
            email: req.user.email,
            collegeId: req.user.collegeId,
            movieName: req.body.movieName,
            showDate: req.body.showDate,
            showTime: req.body.showTime,
            movieId: currentMovie,
            userId: req.user._id,
            status: "Pending",
            ticketsBooked: requestedTickets,
            movieThumbnail: req.body.movieThumbnail
        });

        newOrder.save(function(err){
            if(!err){
              randomNumber = Math.floor(Math.random() * 1000000 + 1);
              extensions = [];
              console.log("Order placed successfully...");
              alert("Order placed successfully...");
              res.redirect("/allMovies");
            }else{
              console.log("Failed to place order...");
              alert("Failed to place order...");

              console.log(err);
            }
          });
    }
});

app.get("/manageMovies", function(req, res){


  if(req.isAuthenticated()){

    if(req.user.type=="Admin"){
      let movies = [];
        Movie.find({}, function(err, allMovies){
          if(err){
            console.log(err);
          }else{
              movies = allMovies;
            res.render("manageMovies", {movies: movies});
          }
      });
    }

  }else{
    alert("This page is only accessible to admins")
    res.redirect("/login");
  }


});

app.post("/updateMovieStatus", function(req, res){

  let status = req.body.movieStatus;
  let currentMovie = req.body.currentMovie;

  console.log("Need to update: ", currentMovie)
  
  Order.updateMany({movieId: currentMovie}, {$set:{status: status}}, { multi: true, upsert: false}, function(err){
    if(!err){
      alert('Status updated on orders table...');
    }else{
      alert('Failed to update Status on orders table');
    }
  });

  Movie.updateOne({_id: currentMovie}, {$set:{status: status}}, function(err){
    if(!err){
      alert('Status updated on movie table...');
      res.redirect("/manageMovies");
    }else{
      alert('Failed to update Status on movies table');
      res.redirect("/manageMovies");
    }
  });



});


app.post("/cancel", function(req, res){
  let currentOrder = req.body.currentOrder;
  let currentMovie = req.body.currentMovie;
  let ticketsBooked = req.body.ticketsBooked;

  var currentAvailableTickets;
  var newTickets;

  Movie.find({_id: currentMovie}, function(err, movie){
    if(!err){
      console.log(movie[0].tickets)
      currentAvailableTickets = movie[0].tickets;
      newTickets = (+currentAvailableTickets) + (+ticketsBooked);
      console.log("Booked = ", ticketsBooked);
      console.log("already = ", currentAvailableTickets);
      console.log("new tickets = ", newTickets);
      // ----------------------------------------

      Movie.updateOne({_id: currentMovie}, {$set:{tickets: newTickets}}, function(err){
        if(!err){
          alert('Tickets Cancelled...');
        }else{
          alert('Failed to Cancel tickets');
        }
      });
    }else{
      console.log("Eorrrrrrrrr")
    }
  });



  Order.deleteOne({_id: currentOrder}, function(err){
    if(err){
      console.log("Unable to delete order.....");
    }else{
      console.log("Order deleted.....");
      res.redirect("/myMovies");
    }
  })
})